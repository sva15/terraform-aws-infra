import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    SNS-triggered Lambda function
    Processes SNS messages from different topics
    """
    logger.info("SNS Event received: %s", json.dumps(event))
    
    results = []
    
    for record in event['Records']:
        try:
            # Verify it's an SNS record
            if record.get('EventSource') != 'aws:sns':
                logger.warning("Skipping non-SNS record: %s", record.get('EventSource'))
                continue
            
            # Process SNS message
            result = process_sns_message(record['Sns'])
            results.append(result)
            
        except Exception as e:
            logger.error("Error processing record: %s", str(e))
            results.append({'status': 'error', 'message_id': record['Sns'].get('MessageId'), 'error': str(e)})
    
    return {
        'statusCode': 200,
        'body': {
            'message': 'SNS processing completed',
            'processed_count': len(results),
            'results': results
        }
    }

def process_sns_message(sns_message):
    """Process individual SNS message"""
    message_id = sns_message['MessageId']
    topic_arn = sns_message['TopicArn']
    subject = sns_message.get('Subject', 'No Subject')
    message = sns_message['Message']
    
    logger.info("Processing SNS message: %s from topic: %s", message_id, topic_arn)
    
    # Parse message (could be JSON or plain text)
    message_data = parse_message(message)
    
    # Route based on topic or message content
    result = route_message(topic_arn, subject, message_data)
    
    logger.info("Completed processing message: %s", message_id)
    
    return {
        'status': 'success',
        'message_id': message_id,
        'topic_arn': topic_arn,
        'subject': subject,
        'result': result
    }

def parse_message(message):
    """Parse SNS message content"""
    try:
        return json.loads(message)
    except json.JSONDecodeError:
        # Return as plain text
        return {'text': message}

def route_message(topic_arn, subject, message_data):
    """Route message based on topic or content"""
    
    # Check for specific topics
    if 'user-notifications' in topic_arn:
        return handle_user_notification(message_data)
    
    elif 'order-updates' in topic_arn:
        return handle_order_update(message_data)
    
    elif 'system-alerts' in topic_arn:
        return handle_system_alert(message_data)
    
    # Check message content for event type
    elif isinstance(message_data, dict) and 'event_type' in message_data:
        return handle_event_type(message_data)
    
    # Default handler
    else:
        return handle_general_message(message_data)

def handle_user_notification(message_data):
    """Handle user-related notifications"""
    logger.info("Processing user notification")
    
    if isinstance(message_data, dict):
        user_email = message_data.get('email')
        action = message_data.get('action')
        
        return {
            'handler': 'user_notification',
            'action': action,
            'user_email': user_email,
            'message': f"Processed user {action} for {user_email}"
        }
    
    return {
        'handler': 'user_notification',
        'message': 'Processed user notification',
        'raw_data': str(message_data)
    }

def handle_order_update(message_data):
    """Handle order-related updates"""
    logger.info("Processing order update")
    
    if isinstance(message_data, dict):
        order_id = message_data.get('order_id')
        status = message_data.get('status')
        
        return {
            'handler': 'order_update',
            'order_id': order_id,
            'status': status,
            'message': f"Order {order_id} updated to {status}"
        }
    
    return {
        'handler': 'order_update',
        'message': 'Processed order update',
        'raw_data': str(message_data)
    }

def handle_system_alert(message_data):
    """Handle system alerts"""
    logger.warning("Processing system alert: %s", message_data)
    
    # Here you could integrate with PagerDuty, Slack, etc.
    return {
        'handler': 'system_alert',
        'severity': 'high',
        'message': 'System alert processed',
        'alert_data': message_data
    }

def handle_event_type(message_data):
    """Handle messages with event_type field"""
    event_type = message_data.get('event_type')
    
    logger.info("Processing event type: %s", event_type)
    
    return {
        'handler': 'event_type',
        'event_type': event_type,
        'message': f"Processed {event_type} event",
        'data': message_data
    }

def handle_general_message(message_data):
    """Handle general messages"""
    logger.info("Processing general message")
    
    return {
        'handler': 'general',
        'message': 'Processed general SNS message',
        'data': message_data
    }